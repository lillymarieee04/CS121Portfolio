package weekFourteen.projectThree;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.runMenu();
    }
}


//thoughts: this project was good to me, it was very forthcoming and understandable. All code was straightforward to do.
// the hardest part is setting up what to do when asking this, but that's good for understanding.
// so simple (yet informative) it reminded me of python.