package packageDemo;

public class StudentTest {
    public static void main(String[] args) {
        Student student = new Student("S12345", "Lilly", "Waterman", 2, 3.75);

        System.out.println("Student ID: " + student.getStudentID());
        System.out.println("First Name: " + student.getFirstName());
        System.out.println("Last Name: " + student.getLastName());
        System.out.println("Grade Level: " + student.getGradeLevel());
        System.out.println("GPA: " + student.getGPA());

        student.setFirstName("Emma");
        student.setLastName("Swift");
        student.setGradeLevel(3);
        student.setGPA(3.90);

        System.out.println("\nUpdated Student Information:");
        System.out.println("First Name: " + student.getFirstName());
        System.out.println("Last Name: " + student.getLastName());
        System.out.println("Grade Level: " + student.getGradeLevel());
        System.out.println("GPA: " + student.getGPA());
    }
}
